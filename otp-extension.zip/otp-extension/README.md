# OTP Authenticator — Chrome Extension

A Chrome extension port of your Python TOTP tray app. Generates time-based one-time passwords (RFC 6238) directly in your browser — no external dependencies.

## Features
- Live TOTP code with countdown timer + progress bar
- Copy to clipboard with one click
- Secret key stored securely in Chrome's local storage
- Works with any standard TOTP service (Google, GitHub, CUNY, etc.)

## Installation

### 1. Unzip / prepare the folder
Make sure the extension folder contains:
```
otp-extension/
├── manifest.json
├── popup.html
├── popup.js
├── otp.js
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

### 2. Load into Chrome
1. Open Chrome and navigate to `chrome://extensions`
2. Enable **Developer mode** (toggle in the top-right corner)
3. Click **Load unpacked**
4. Select the `otp-extension` folder
5. The OTP icon will appear in your toolbar

### 3. Add your secret key
1. Click the extension icon in the toolbar
2. Click **Add Secret Key** (or the ⚙ gear icon)
3. Paste your Base32 TOTP secret (the same `CUNY_KEY` you used in `.env`)
4. Click **Save & Activate**

> **Note:** Your secret is stored locally in Chrome's storage — it never leaves your browser.

## Security Notes
- The secret is stored in `chrome.storage.local` (not synced to your Google account)
- To remove the secret, go to Settings → click the gear icon → save a blank key, or clear extension data from `chrome://extensions`

## Migrating from the Python app
Your `CUNY_KEY` Base32 secret works directly — just paste it into the extension's setup screen.
